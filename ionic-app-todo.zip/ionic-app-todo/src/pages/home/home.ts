import { Component } from '@angular/core';
import {ActionSheet, ModalController, NavController, Toast} from 'ionic-angular';
import { AddItemPage } from '../add-item/add-item'
import { ItemDetailPage } from '../item-detail/item-detail';
import { Data } from '../../providers/data/data';
import {AuthService} from "../../providers/auth-service";
import {LoginPage} from "../login/login";

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  username = '';
  email = '';

  public items = [];

  public pepperoni:boolean = true;

  constructor(public navCtrl: NavController, public modalCtrl: ModalController, public dataService: Data, private auth: AuthService) {

    let info = this.auth.getUserInfo();
    this.username = info['name'];
    this.email = info['email'];

    this.dataService.getData().then((todos) => {

      if(todos){
        this.items = todos;
      }

    });


  }

  ionViewDidLoad(){

  }

  addItem(){

    let addModal = this.modalCtrl.create(AddItemPage);

    addModal.onDidDismiss((item) => {

      if(item){
        this.saveItem(item);
      }

    });

    addModal.present();

  }

  saveItem(item){
    this.items.push(item);
    this.dataService.save(this.items);
  }

  viewItem(item){
    this.navCtrl.push(ItemDetailPage, {
      item: item
    });
  }

  removeItem(item){

    let index = this.items.indexOf(item);

    if(index > -1){
      this.items.splice(index, 1);
    }
  }

  public logout() {
    this.auth.logout().subscribe(succ => {
      this.navCtrl.setRoot(LoginPage)
    });
  }

}
